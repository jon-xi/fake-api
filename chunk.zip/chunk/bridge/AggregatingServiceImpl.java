package hk.org.empf.cas.contribution.chunk.bridge;

import hk.org.empf.cas.contribution.chunk.AggregatingService;
import hk.org.empf.cas.contribution.chunk.ProfilingService;
import hk.org.empf.cas.contribution.chunk.model.UploadChunkMaster;
import lombok.extern.slf4j.Slf4j;
import org.springframework.lang.NonNull;
import org.springframework.stereotype.Component;

@Slf4j
@Component
@SuppressWarnings("unused")
public class AggregatingServiceImpl implements AggregatingService {
    private final ProfilingService profilingService;

    public AggregatingServiceImpl(ProfilingService profilingService) {
        this.profilingService = profilingService;
    }

    @Override
    public boolean aggregate(@NonNull UploadChunkMaster master) {
        log.info("upload-uuid: " + master.getUploadUuid());
        log.info("chunk-size: " + master.getChunkSize());
        log.info("file-type: " + master.getFileType());
        log.info("total-chunks: " + master.getTotalChunks());
        log.info("done-chunks: " + master.getDoneChunks());
        log.info("status-code: " + master.getStatusCode());

        profilingService.stopWatch("chunk-processing");

        return false;
    }
}
