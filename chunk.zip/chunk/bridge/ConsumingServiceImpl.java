package hk.org.empf.cas.contribution.chunk.bridge;

import hk.org.empf.cas.contribution.chunk.ConsumingService;
import hk.org.empf.cas.contribution.chunk.ProfilingService;
import hk.org.empf.cas.contribution.chunk.model.ChunkContext;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.config.ConfigurableBeanFactory;
import org.springframework.context.annotation.Scope;
import org.springframework.lang.NonNull;
import org.springframework.stereotype.Component;

@Slf4j
@Component
@SuppressWarnings("unused")
@Scope(value = ConfigurableBeanFactory.SCOPE_PROTOTYPE)
public class ConsumingServiceImpl implements ConsumingService {
    private final ProfilingService profilingService;

    public ConsumingServiceImpl(ProfilingService profilingService) {
        this.profilingService = profilingService;
    }

    @Override
    public boolean consume(@NonNull ChunkContext context) {
        profilingService.startWatch("chunk-processing");

        for (var payrollRecord : context.getPayrollRecords()) {
            try {
                Thread.sleep(500);
            } catch (InterruptedException ignored) {
                continue;
            }

            log.info("serial-no: " + payrollRecord.getSerialNo());

            if (payrollRecord.getSerialNo() >= 100) {
                profilingService.stopWatch("chunk-processing");
            }
        }

        return false;
    }
}
