package hk.org.empf.cas.contribution.chunk.service;

import hk.org.empf.cas.contribution.chunk.BridgingService;
import lombok.AllArgsConstructor;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.lang.NonNull;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
@AllArgsConstructor
public class BridgingServiceImpl implements BridgingService {
    private static final String FMT_CHECK_GLOBAL_TEMPORARY_TABLE =
            "SELECT COUNT(TABLE_NAME) FROM USER_TABLES WHERE TEMPORARY = 'Y' AND TABLE_NAME = '%s'";
    private static final String FMT_CREATE_GLOBAL_TEMPORARY_TABLE =
            "CREATE GLOBAL TEMPORARY %s ON COMMIT PRESERVE ROWS";
    private static final String FMT_TRUNCATE_GLOBAL_TEMPORARY_TABLE =
            "TRUNCATE TABLE %s";
    private static final String FMT_DROP_GLOBAL_TEMPORARY_TABLE =
            "DROP TABLE %s";

    private static final String TABLE_GTT_UPLOAD_CHUNK_MASTER =
            "TABLE GTT_UPLOAD_CHUNK_MASTER (\n" +
                    "  UPLOAD_UUID RAW(16) NOT NULL,\n" +
                    "  FILE_TYPE NUMBER NOT NULL,\n" +
                    "  CHUNK_SIZE NUMBER NOT NULL,\n" +
                    "  TOTAL_CHUNKS NUMBER NOT NULL,\n" +
                    "  DONE_CHUNKS NUMBER NOT NULL,\n" +
                    "  STATUS_CODE NUMBER NOT NULL,\n" +
                    "  CREATED_AT TIMESTAMP DEFAULT CURRENT_TIMESTAMP,\n" +
                    "  UPDATED_AT TIMESTAMP DEFAULT CURRENT_TIMESTAMP,\n" +
                    "  PRIMARY KEY(UPLOAD_UUID)\n" +
                    ")\n";

    private static final String TABLE_GTT_UPLOAD_CHUNK_RECORD =
            "TABLE GTT_UPLOAD_CHUNK_RECORD (\n" +
                    "  UPLOAD_CHUNK_UUID RAW(16) NOT NULL,\n" +
                    "  UPLOAD_UUID RAW(16) NOT NULL,\n" +
                    "  CHUNK_SEQ NUMBER NOT NULL,\n" +
                    "  UPLOAD_CONTENT CLOB NOT NULL,\n" +
                    "  TOTAL_RECORDS NUMBER NOT NULL,\n" +
                    "  STATUS_CODE NUMBER NOT NULL,\n" +
                    "  CREATED_AT TIMESTAMP DEFAULT CURRENT_TIMESTAMP,\n" +
                    "  UPDATED_AT TIMESTAMP DEFAULT CURRENT_TIMESTAMP,\n" +
                    "  PRIMARY KEY(UPLOAD_CHUNK_UUID)\n" +
                    ")";

    private final JdbcTemplate jdbcTemplate;

    @Override
    @Transactional
    public void createChunkingTables() {
        removeBridgeTable("GTT_UPLOAD_CHUNK_RECORD");
        removeBridgeTable("GTT_UPLOAD_CHUNK_MASTER");

        createBridgeTable("GTT_UPLOAD_CHUNK_MASTER", TABLE_GTT_UPLOAD_CHUNK_MASTER);
        createBridgeTable("GTT_UPLOAD_CHUNK_RECORD", TABLE_GTT_UPLOAD_CHUNK_RECORD);
    }

    @Override
    public void removeBridgeTable(@NonNull String tableName) {
        var bridgeName = tableName.toUpperCase();
        if (checkBridgeTable(bridgeName) > 0) {
            truncateBridgeTable(bridgeName);
            dropBridgeTable(bridgeName);
        }
    }

    @Override
    public void createBridgeTable(@NonNull String tableName, @NonNull String tableDef) {
        var bridgeName = tableName.toUpperCase();
        if (checkBridgeTable(bridgeName) == 0) {
            createBridgeTable(tableDef);
        }
    }

    private void truncateBridgeTable(String tableName) {
        jdbcTemplate.execute(String.format(FMT_TRUNCATE_GLOBAL_TEMPORARY_TABLE, tableName));
    }

    private void dropBridgeTable(String tableName) {
        jdbcTemplate.execute(String.format(FMT_DROP_GLOBAL_TEMPORARY_TABLE, tableName));
    }

    private void createBridgeTable(String tableDef) {
        jdbcTemplate.execute(String.format(FMT_CREATE_GLOBAL_TEMPORARY_TABLE, tableDef));
    }

    private Integer checkBridgeTable(String tableName) {
        return jdbcTemplate.queryForObject(
                String.format(FMT_CHECK_GLOBAL_TEMPORARY_TABLE, tableName),
                Integer.class
        );
    }
}
