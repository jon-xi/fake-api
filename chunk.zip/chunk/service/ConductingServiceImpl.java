package hk.org.empf.cas.contribution.chunk.service;

import com.fasterxml.jackson.databind.JsonNode;
import hk.org.empf.cas.contribution.chunk.ConductingService;
import hk.org.empf.cas.contribution.chunk.UploadFileType;
import hk.org.empf.cas.contribution.chunk.UploadStatusCode;
import hk.org.empf.cas.contribution.chunk.model.*;
import hk.org.empf.cas.contribution.chunk.util.JsonUtils;
import hk.org.empf.cas.contribution.repository.chunk.ChunkTestMapper;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.lang.NonNull;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.*;
import java.util.stream.Collectors;
import java.util.stream.IntStream;
import java.util.stream.StreamSupport;

@Slf4j
@Service
@AllArgsConstructor
public class ConductingServiceImpl implements ConductingService {
    private static final int FETCH_LIMITS = 1;

    private final ChunkTestMapper chunkTestMapper;

    private static PayrollRecord payrollRecord(JsonNode jsonNode) {
        return PayrollRecord.builder()
                .serialNo(jsonNode.path("serialNo").asInt())
                .build();
    }

    private static List<PayrollRecord> payrollRecords(UploadChunkRecord chunkRecord) {
        var rootNode = JsonUtils.readTree(chunkRecord.getUploadContent());
        if (Objects.isNull(rootNode)) {
            return Collections.emptyList();
        }
        return StreamSupport.stream(rootNode.spliterator(), false)
                .map(ConductingServiceImpl::payrollRecord)
                .collect(Collectors.toList());
    }

    private static UploadStatusCode statusCode(boolean hasError) {
        return hasError ? UploadStatusCode.FINISHED
                : UploadStatusCode.COMPLETED;
    }

    private static ChunkContext chunkContext(UploadChunkRecord chunkRecord, UUID authPersonUuid) {
        chunkRecord.setStatusCode(UploadStatusCode.STARTED.getValue());
        return ChunkContext.builder()
                .authPersonUuid(authPersonUuid)
                .payrollRecords(payrollRecords(chunkRecord))
                .chunkRecord(chunkRecord)
                .build();
    }

    @NonNull
    @Override
    @Transactional
    public int completeMaster(@NonNull UUID uploadUuid, boolean hasError) {
        var statusCode = statusCode(hasError);
        return chunkTestMapper.selectMaster(uploadUuid).stream().findAny()
                .map(master -> chunkTestMapper.updateMasterStatus(
                        uploadUuid, statusCode.getValue()
                )).orElse(0);
    }

    @NonNull
    @Override
    @Transactional
    public int completeChunk(@NonNull UUID chunkUuid, boolean hasError) {
        var statusCode = statusCode(hasError);
        return chunkTestMapper.selectMasterByChunk(chunkUuid).stream().findAny()
                .map(master -> updateChunkToCompleted(master, statusCode, chunkUuid))
                .orElse(0);
    }

    @NonNull
    @Override
    @Transactional
    public Optional<UploadChunkMaster> startCompletableMaster() {
        return chunkTestMapper.selectMasterIDs(FETCH_LIMITS).stream().findAny()
                .flatMap(uuid -> chunkTestMapper.selectMaster(uuid).stream().findAny());
    }

    @NonNull
    @Override
    @Transactional
    public Optional<ChunkContext> startPendingChunk(@NonNull MessageContext context) {
        return chunkTestMapper.selectNewChunk(context.getUploadChunkUuid()).stream().findAny()
                .map(chunk -> chunkContext(chunk, context.getAuthPersonUuid()))
                .filter(chunk -> updateChunkToStarted(chunk) > 0);
    }

    @NonNull
    @Override
    @Transactional
    public Optional<ChunkContext> startPendingChunk(@NonNull UploadFileType fileType, @NonNull UUID authPersonUuid) {
        return chunkTestMapper.selectNewChunkIDs(fileType.getValue(), FETCH_LIMITS).stream().findAny()
                .flatMap(uuid -> chunkTestMapper.selectNewChunk(uuid).stream().findAny())
                .map(chunk -> chunkContext(chunk, authPersonUuid))
                .filter(chunk -> updateChunkToStarted(chunk) > 0);
    }

    private int updateChunkToStarted(ChunkContext context) {
        return chunkTestMapper.updateChunkToStarted(
                context.getChunkRecord().getUploadChunkUuid()
        );
    }

    private int updateChunkToCompleted(UploadChunkMaster master, UploadStatusCode statusCode, UUID chunkUuid) {
        return IntStream.of(chunkTestMapper.updateChunkStatus(chunkUuid, statusCode.getValue()),
                chunkTestMapper.updateMasterStatus(
                        master.getUploadUuid(), UploadStatusCode.STARTED.getValue()
                ),
                chunkTestMapper.updateMasterProgress(master.getUploadUuid())
        ).sum();
    }
}
