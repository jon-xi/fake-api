package hk.org.empf.cas.contribution.chunk.service;

import hk.org.empf.cas.contribution.chunk.DistributingService;
import hk.org.empf.cas.contribution.chunk.UploadStatusCode;
import hk.org.empf.cas.contribution.chunk.model.ChunkContext;
import hk.org.empf.cas.contribution.chunk.model.DispatchContext;
import hk.org.empf.cas.contribution.chunk.model.UploadChunkMaster;
import hk.org.empf.cas.contribution.chunk.model.UploadChunkRecord;
import hk.org.empf.cas.contribution.repository.chunk.ChunkTestMapper;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.ibatis.session.ExecutorType;
import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;
import org.springframework.lang.NonNull;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Slf4j
@Service
@AllArgsConstructor
public class DistributingServiceImpl implements DistributingService {
    private final SqlSessionFactory sqlSessionFactory;

    private static UploadChunkMaster chunkMaster(DispatchContext context) {
        return UploadChunkMaster.builder()
                .statusCode(UploadStatusCode.CREATED.getValue())
                .totalChunks(context.getChunkContexts().size())
                .fileType(context.getType().getValue())
                .uploadUuid(context.getUploadUuid())
                .chunkSize(context.getChunkSize())
                .doneChunks(0)
                .build();
    }

    private static UploadChunkRecord chunkRecord(ChunkContext context) {
        var chunkRecord = context.getChunkRecord();
        return UploadChunkRecord.builder()
                .totalRecords(context.getPayrollRecords().size())
                .uploadChunkUuid(chunkRecord.getUploadChunkUuid())
                .uploadContent(chunkRecord.getUploadContent())
                .uploadUuid(chunkRecord.getUploadUuid())
                .statusCode(chunkRecord.getStatusCode())
                .chunkSeq(chunkRecord.getChunkSeq())
                .build();
    }

    @NonNull
    @Override
    @Transactional
    public boolean distribute(@NonNull DispatchContext context) {
        try (SqlSession sqlSession = sqlSessionFactory.openSession(ExecutorType.BATCH)) {
            var mapper = sqlSession.getMapper(ChunkTestMapper.class);

            mapper.saveMaster(chunkMaster(context));
            context.getChunkContexts().stream()
                    .map(DistributingServiceImpl::chunkRecord)
                    .forEach(mapper::saveChunk);

            sqlSession.flushStatements();
            sqlSession.commit();

            return true;
        } catch (Exception ignored) {
            return false;
        }
    }
}
