package hk.org.empf.cas.contribution.chunk.service;

import com.google.common.collect.Lists;
import hk.org.empf.cas.contribution.chunk.ChunkingService;
import hk.org.empf.cas.contribution.chunk.config.ChunkingConfig;
import hk.org.empf.cas.contribution.chunk.model.*;
import hk.org.empf.cas.contribution.chunk.util.JsonUtils;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.lang.NonNull;
import org.springframework.stereotype.Service;
import reactor.util.function.Tuples;

import java.util.List;
import java.util.Objects;
import java.util.UUID;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

@Slf4j
@Service
@AllArgsConstructor
public class ChunkingServiceImpl implements ChunkingService {
    private final ChunkingConfig chunkingConfig;

    private static DispatchContext dispatchContext(
            List<ChunkContext> chunkContexts,
            UploadContext context,
            int size) {
        Objects.requireNonNull(context);
        Objects.requireNonNull(context.getBulkUpload());
        return DispatchContext.builder()
                .chunkSize(size)
                .type(context.getType())
                .chunkContexts(chunkContexts)
                .uploadUuid(context.getBulkUpload().getUploadUuid())
                .build();
    }

    private static UploadChunkRecord chunkRecord(
            List<PayrollRecord> payrollRecords,
            UUID uploadUuid,
            int index) {
        Objects.requireNonNull(uploadUuid);
        Objects.requireNonNull(payrollRecords);
        return UploadChunkRecord.builder()
                .statusCode(0)
                .chunkSeq(index + 1)
                .uploadUuid(uploadUuid)
                .uploadChunkUuid(UUID.randomUUID())
                .totalRecords(payrollRecords.size())
                .uploadContent(JsonUtils.valueToString(payrollRecords))
                .build();
    }

    private static ChunkContext chunkContext(
            List<PayrollRecord> payrollRecords,
            UploadContext context,
            int index) {
        Objects.requireNonNull(context);
        Objects.requireNonNull(payrollRecords);
        Objects.requireNonNull(context.getBulkUpload());
        var chunkRecord = chunkRecord(
                payrollRecords,
                context.getBulkUpload().getUploadUuid(),
                index
        );
        return ChunkContext.builder()
                .chunkRecord(chunkRecord)
                .payrollRecords(payrollRecords)
                .authPersonUuid(context.getAuthPersonUuid())
                .build();
    }

    @NonNull
    @Override
    public DispatchContext chunk(@NonNull UploadContext context) {
        Objects.requireNonNull(context);
        var size = chunkingConfig.getChunkSize();
        var chunks = Lists.partition(context.getPayrollRecords(), size);
        var chunkContexts = IntStream.range(0, chunks.size()).boxed()
                .map(index -> Tuples.of(index, chunks.get(index)))
                .map(tuple -> chunkContext(tuple.getT2(), context, tuple.getT1()))
                .collect(Collectors.toList());
        return dispatchContext(chunkContexts, context, size);
    }
}
