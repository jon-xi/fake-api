package hk.org.empf.cas.contribution.chunk.service;

import hk.org.empf.cas.contribution.chunk.PublishingService;
import hk.org.empf.cas.contribution.chunk.UploadFileType;
import hk.org.empf.cas.contribution.chunk.config.ChunkingConfig;
import hk.org.empf.cas.contribution.chunk.model.ChunkContext;
import hk.org.empf.cas.contribution.chunk.model.DispatchContext;
import hk.org.empf.cas.contribution.chunk.model.MessageContext;
import hk.org.empf.cas.contribution.chunk.util.JsonUtils;
import hk.org.empf.common.dto.transactionaloutbox.Command;
import hk.org.empf.common.service.TransactionalOutboxService;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.logging.log4j.util.Strings;
import org.springframework.lang.NonNull;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.UUID;
import java.util.stream.Collectors;

@Slf4j
@Service
@AllArgsConstructor
public class PublishingServiceImpl implements PublishingService {
    private static final String OPERATION_SUBJECT = "chunking";
    private static final String REQUESTOR_MODULE = "CONTRIBUTION";
    private static final String OPERATION_TYPE = "publish";
    private static final String VERSION = "v1";

    private final TransactionalOutboxService transactionalOutboxService;
    private final ChunkingConfig chunkingConfig;

    private static MessageContext messageContext(ChunkContext chunkContext) {
        Objects.requireNonNull(chunkContext);
        Objects.requireNonNull(chunkContext.getChunkRecord());
        return MessageContext.builder()
                .authPersonUuid(chunkContext.getAuthPersonUuid())
                .bulkUploadUuid(chunkContext.getChunkRecord().getUploadUuid())
                .uploadChunkUuid(chunkContext.getChunkRecord().getUploadChunkUuid())
                .build();
    }

    @NonNull
    @Override
    public List<UUID> publish(@NonNull DispatchContext context) {
        Objects.requireNonNull(context);
        var contexts = context.getChunkContexts().stream()
                .map(PublishingServiceImpl::messageContext)
                .collect(Collectors.toList());
        return publishMessages(contexts, context.getType());
    }

    private List<UUID> publishMessages(List<MessageContext> messages, UploadFileType fileType) {
        Objects.requireNonNull(messages);
        Objects.requireNonNull(fileType);
        return messages.stream().map(message -> publishMessage(message, fileType))
                .collect(Collectors.toList());
    }

    private UUID publishMessage(MessageContext message, UploadFileType fileType) {
        Objects.requireNonNull(message);
        var command = Command.builder()
                .data(JsonUtils.valueToTree(message))
                .destinationTopic(destTopic(fileType))
                .operationSubject(OPERATION_SUBJECT)
                .commandReplyTo(destQueue(fileType))
                .requestorModule(REQUESTOR_MODULE)
                .operationType(OPERATION_TYPE)
                .version(VERSION)
                .build();
        return transactionalOutboxService.insertCommandToOutbox(command);
    }

    private String destTopic(UploadFileType fileType) {
        return chunkingConfig.getTopicMap().entrySet().stream()
                .filter(entry -> entry.getKey().equalsIgnoreCase(fileType.name()))
                .findAny().map(Map.Entry::getValue)
                .orElse(Strings.EMPTY);
    }

    private String destQueue(UploadFileType fileType) {
        return chunkingConfig.getQueueMap().entrySet().stream()
                .filter(entry -> entry.getKey().equalsIgnoreCase(fileType.name()))
                .findAny().map(Map.Entry::getValue)
                .orElse(Strings.EMPTY);
    }
}
