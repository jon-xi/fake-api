package hk.org.empf.cas.contribution.chunk.service;

import hk.org.empf.cas.contribution.chunk.ProfilingService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.lang.NonNull;
import org.springframework.stereotype.Service;
import org.springframework.util.StopWatch;

import java.util.HashMap;
import java.util.Map;

@Slf4j
@Service
@SuppressWarnings("unused")
public class ProfilingServiceImpl implements ProfilingService {
    private final Map<String, StopWatch> watchMap;

    public ProfilingServiceImpl() {
        this.watchMap = new HashMap<>();
    }

    @Override
    public void startWatch(@NonNull String id) {
        watchMap.computeIfAbsent(id, key -> {
            var watch = new StopWatch(key);
            watch.start(id);
            return watch;
        });
    }

    @Override
    public void stopWatch(@NonNull String id) {
        watchMap.computeIfPresent(id, (k, v) -> {
            v.stop();
            log.info("watch id: " + v.getTotalTimeSeconds());
            return null;
        });
    }
}
