package hk.org.empf.cas.contribution.chunk;

import hk.org.empf.cas.contribution.chunk.model.DispatchContext;
import hk.org.empf.cas.contribution.chunk.model.UploadContext;

public interface ChunkingService {
    DispatchContext chunk(UploadContext context);
}
