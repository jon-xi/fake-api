package hk.org.empf.cas.contribution.chunk;

import lombok.Getter;

import java.util.Arrays;

/*
 FINISHED means done with errors
 COMPLETED means done without errors
 */
@Getter
public enum UploadStatusCode {
    CREATED(1),
    STARTED(2),
    FINISHED(3),
    COMPLETED(4);

    private final int value;

    UploadStatusCode(int value) {
        this.value = value;
    }

    public static UploadStatusCode valueOf(final int value) {
        return Arrays.stream(UploadStatusCode.values())
                .filter(type -> type.value == value)
                .findFirst().orElse(UploadStatusCode.CREATED);
    }

    public static UploadStatusCode nameOf(final String value) {
        return Arrays.stream(UploadStatusCode.values())
                .filter(type -> type.name().equalsIgnoreCase(value))
                .findFirst().orElse(UploadStatusCode.CREATED);
    }
}
