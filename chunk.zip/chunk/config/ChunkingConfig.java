package hk.org.empf.cas.contribution.chunk.config;

import lombok.Data;
import lombok.Synchronized;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Map;

@Data
@SuppressWarnings("unused")
@Configuration(proxyBeanMethods = false)
@ConfigurationProperties(prefix = "app.task.chunking")
public class ChunkingConfig implements InitializingBean {
    private Map<String, String> queueMap;
    private Map<String, String> topicMap;

    private List<String> queueNames;
    private List<String> queueTypes;

    private int chunkSize;

    public String currentQueue() {
        return queueNames.get(0);
    }

    public String currentType() {
        return queueTypes.get(0);
    }

    @Synchronized
    public void rotateQueues() {
        Collections.rotate(queueNames, 1);
        Collections.rotate(queueTypes, 1);
    }

    @Override
    public void afterPropertiesSet() {
        queueNames = new ArrayList<>(queueMap.values());
        queueTypes = new ArrayList<>(queueMap.keySet());
    }
}
