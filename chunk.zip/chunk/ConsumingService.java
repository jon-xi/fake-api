package hk.org.empf.cas.contribution.chunk;

import hk.org.empf.cas.contribution.chunk.model.ChunkContext;

public interface ConsumingService {
    boolean consume(ChunkContext context);
}
