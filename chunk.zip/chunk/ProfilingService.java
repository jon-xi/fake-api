package hk.org.empf.cas.contribution.chunk;

public interface ProfilingService {
    void startWatch(String id);
    void stopWatch(String id);
}
