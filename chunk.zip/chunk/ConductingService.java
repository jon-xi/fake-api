package hk.org.empf.cas.contribution.chunk;

import hk.org.empf.cas.contribution.chunk.model.ChunkContext;
import hk.org.empf.cas.contribution.chunk.model.MessageContext;
import hk.org.empf.cas.contribution.chunk.model.UploadChunkMaster;
import org.springframework.lang.NonNull;

import java.util.Optional;
import java.util.UUID;

@SuppressWarnings("UnusedReturnValue")
public interface ConductingService {
    Optional<UploadChunkMaster> startCompletableMaster();

    Optional<ChunkContext> startPendingChunk(MessageContext context);

    Optional<ChunkContext> startPendingChunk(UploadFileType fileType, UUID authPersonUuid);

    int completeMaster(@NonNull UUID uploadUuid, boolean hasError);

    int completeChunk(@NonNull UUID chunkUuid, boolean hasError);
}
