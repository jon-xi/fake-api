package hk.org.empf.cas.contribution.chunk;

import lombok.Getter;

import java.util.Arrays;

@Getter
public enum UploadFileType {
    LARGE(1),
    MEDIUM(2),
    SMALL(3);

    private final int value;

    UploadFileType(int value) {
        this.value = value;
    }

    public static UploadFileType valueOf(final int value) {
        return Arrays.stream(UploadFileType.values())
                .filter(type -> type.value == value)
                .findFirst().orElse(UploadFileType.LARGE);
    }

    public static UploadFileType nameOf(final String value) {
        return Arrays.stream(UploadFileType.values())
                .filter(type -> type.name().equalsIgnoreCase(value))
                .findFirst().orElse(UploadFileType.LARGE);
    }
}
