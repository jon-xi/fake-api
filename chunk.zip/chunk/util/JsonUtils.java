package hk.org.empf.cas.contribution.chunk.util;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.apache.logging.log4j.util.Strings;
import org.springframework.lang.Nullable;

import java.util.Objects;

@SuppressWarnings("unused")
public final class JsonUtils {
    private static final ObjectMapper OBJECT_MAPPER = new ObjectMapper();

    private JsonUtils() {
    }

    public static String valueToString(Object value) {
        Objects.requireNonNull(value);
        try {
            return OBJECT_MAPPER.writeValueAsString(value);
        } catch (JsonProcessingException e) {
            return Strings.EMPTY;
        }
    }

    public static JsonNode valueToTree(Object value) {
        Objects.requireNonNull(value);
        return OBJECT_MAPPER.valueToTree(value);
    }

    @Nullable
    public static JsonNode readTree(String content) {
        Objects.requireNonNull(content);
        try {
            return OBJECT_MAPPER.readTree(content);
        } catch (JsonProcessingException e) {
            return null;
        }
    }

    @Nullable
    public static <T> T treeToValue(JsonNode jsonNode, Class<T> clazz) {
        Objects.requireNonNull(jsonNode);
        Objects.requireNonNull(clazz);
        try {
            return OBJECT_MAPPER.treeToValue(jsonNode, clazz);
        } catch (JsonProcessingException e) {
            return null;
        }
    }
}
