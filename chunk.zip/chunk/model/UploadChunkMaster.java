package hk.org.empf.cas.contribution.chunk.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.UUID;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class UploadChunkMaster {
    // primary key
    private UUID uploadUuid;

    // large=1, medium=2, small=3
    private int fileType;
    private int chunkSize;
    private int totalChunks;

    // updated by consumers
    private int doneChunks;

    // created=1, started=2, finished=3, completed=4
    private int statusCode;
}
