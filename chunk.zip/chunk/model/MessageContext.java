package hk.org.empf.cas.contribution.chunk.model;

import lombok.Builder;
import lombok.Getter;

import java.util.UUID;

@Getter
@Builder
public final class MessageContext {
    private UUID bulkUploadUuid;
    private UUID uploadChunkUuid;
    private UUID authPersonUuid;
}
