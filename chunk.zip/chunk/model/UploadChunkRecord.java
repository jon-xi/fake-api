package hk.org.empf.cas.contribution.chunk.model;

import com.fasterxml.jackson.annotation.JsonIgnore;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.UUID;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class UploadChunkRecord {
    private UUID uploadChunkUuid;

    // business key: uploadUuid + chunkSeq
    private UUID uploadUuid;
    private int chunkSeq;

    @JsonIgnore
    private String uploadContent;

    private int totalRecords;

    // created=1, started=2, finished=3, completed=4
    private int statusCode;
}
