package hk.org.empf.cas.contribution.chunk.model;

import hk.org.empf.cas.contribution.chunk.UploadFileType;
import lombok.Builder;
import lombok.Getter;

import java.util.List;
import java.util.UUID;

@Getter
@Builder
public final class DispatchContext {
    private List<ChunkContext> chunkContexts;
    private UploadFileType type;
    private UUID uploadUuid;
    private int chunkSize;
}
