package hk.org.empf.cas.contribution.chunk.model;

import lombok.Builder;
import lombok.Getter;

import java.util.List;
import java.util.UUID;

@Getter
@Builder
public final class ChunkContext {
    private List<PayrollRecord> payrollRecords;
    private UploadChunkRecord chunkRecord;
    private UUID authPersonUuid;
}
