package hk.org.empf.cas.contribution.chunk.model;

import com.fasterxml.jackson.annotation.JsonIgnore;
import hk.org.empf.cas.contribution.chunk.UploadFileType;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.UUID;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class BulkUpload {
    private UUID uploadUuid;

    @JsonIgnore
    private String uploadContent;
}
