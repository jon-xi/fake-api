package hk.org.empf.cas.contribution.chunk.scheduling;

import hk.org.empf.cas.contribution.chunk.AggregatingService;
import hk.org.empf.cas.contribution.chunk.ConductingService;
import hk.org.empf.cas.contribution.chunk.model.UploadChunkMaster;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.lang.Nullable;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;
import reactor.util.function.Tuple2;
import reactor.util.function.Tuples;

import java.util.Objects;
import java.util.UUID;

@Slf4j
@Component
@SuppressWarnings("unused")
public class UploadAggregator {
    private final ConductingService conductingService;

    @Nullable
    private AggregatingService aggregatingService;

    @Autowired
    public UploadAggregator(ConductingService conductingService) {
        this.conductingService = conductingService;
    }

    @Autowired(required = false)
    public void setAggregatorService(@Nullable AggregatingService aggregatingService) {
        this.aggregatingService = aggregatingService;
    }

    @Scheduled(fixedDelayString = "${app.task.chunking.aggregator-interval:3000}")
    public void process() {
        if (Objects.nonNull(aggregatingService)) {
            conductingService.startCompletableMaster()
                    .map(master -> Tuples.of(
                            master.getUploadUuid(),
                            aggregate(master)
                    )).ifPresent(this::completeMaster);
        }

        log.info("on UploadAggregator -> process");
    }

    private void completeMaster(Tuple2<UUID, Boolean> tuple) {
        conductingService.completeMaster(tuple.getT1(), tuple.getT2());
    }

    private boolean aggregate(UploadChunkMaster master) {
        try {
            if (Objects.nonNull(aggregatingService)) {
                return aggregatingService.aggregate(master);
            }
        } catch (Exception ignored) {
        }
        return true;
    }
}
