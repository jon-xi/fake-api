package hk.org.empf.cas.contribution.chunk.scheduling;

import com.fasterxml.jackson.core.JsonProcessingException;
import hk.org.empf.cas.contribution.chunk.ConductingService;
import hk.org.empf.cas.contribution.chunk.ConsumingService;
import hk.org.empf.cas.contribution.chunk.UploadFileType;
import hk.org.empf.cas.contribution.chunk.config.ChunkingConfig;
import hk.org.empf.cas.contribution.chunk.model.ChunkContext;
import hk.org.empf.cas.contribution.chunk.model.MessageContext;
import hk.org.empf.cas.contribution.chunk.util.JsonUtils;
import hk.org.empf.cas.contribution.config.utils.UserUtil;
import hk.org.empf.common.dto.transactionaloutbox.Command;
import hk.org.empf.common.service.JmsTemplateService.JmsTemplateHolder;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jms.core.JmsTemplate;
import org.springframework.lang.Nullable;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;
import reactor.util.function.Tuple2;
import reactor.util.function.Tuples;

import javax.jms.JMSException;
import javax.jms.Message;
import javax.jms.TextMessage;
import java.util.Objects;
import java.util.Optional;
import java.util.UUID;

import static org.springframework.jms.support.destination.JmsDestinationAccessor.RECEIVE_TIMEOUT_NO_WAIT;

@Slf4j
@Component
@SuppressWarnings("unused")
public class UploadProcessor2 {
    private final JmsTemplateHolder jmsTemplateHolder;
    private final ConductingService conductingService;
    private final ChunkingConfig chunkingConfig;

    @Nullable
    private ConsumingService consumingService;

    @Autowired
    public UploadProcessor2(JmsTemplateHolder jmsTemplateHolder,
                            ConductingService conductingService,
                            ChunkingConfig chunkingConfig) {
        this.jmsTemplateHolder = jmsTemplateHolder;
        this.conductingService = conductingService;
        this.chunkingConfig = chunkingConfig;
    }

    private static Optional<Command> safeCommand(Message message) {
        if (Objects.isNull(message)) {
            return Optional.empty();
        }
        try {
            if (message instanceof TextMessage) {
                return Optional.of(
                        Command.toCommand((TextMessage) message)
                );
            }
        } catch (JMSException | JsonProcessingException ignored) {
        }
        return Optional.empty();
    }

    public static UUID authPersonUuid() {
        return UserUtil.getLoginUserUUID();
    }

    @Autowired(required = false)
    public void setConsumerService(@Nullable ConsumingService consumingService) {
        this.consumingService = consumingService;
    }

    @Scheduled(fixedDelayString = "${app.task.chunking.consumer-interval:3000}")
    public void process() {
        if (Objects.nonNull(consumingService)) {
            var fileType = UploadFileType.nameOf(
                    chunkingConfig.currentType()
            );

            var message = jmsTemplate().receive(
                    chunkingConfig.currentQueue()
            );

            safeCommand(message).flatMap(this::messageContext)
                    .flatMap(conductingService::startPendingChunk)
                    .or(() -> conductingService.startPendingChunk(fileType, authPersonUuid()))
                    .map(context -> Tuples.of(
                            context.getChunkRecord().getUploadChunkUuid(),
                            consume(context)
                    )).ifPresent(this::completeChunk);

//            chunkingConfig.rotateQueues();
        }

        log.info("on UploadProcessor -> process");
    }

    private void completeChunk(Tuple2<UUID, Boolean> tuple) {
        conductingService.completeChunk(tuple.getT1(), tuple.getT2());
    }

    private boolean consume(ChunkContext context) {
        try {
            if (Objects.nonNull(consumingService)) {
                return consumingService.consume(context);
            }
        } catch (Exception ignored) {
        }
        return true;
    }

    private Optional<MessageContext> messageContext(Command command) {
        return Optional.ofNullable(JsonUtils.treeToValue(
                command.getData(), MessageContext.class
        ));
    }

    private JmsTemplate jmsTemplate() {
        var template = jmsTemplateHolder.getJmsTemplate();
        var timeout = template.getReceiveTimeout();
        if (timeout != RECEIVE_TIMEOUT_NO_WAIT) {
            template.setReceiveTimeout(RECEIVE_TIMEOUT_NO_WAIT);
        }
        return template;
    }
}
