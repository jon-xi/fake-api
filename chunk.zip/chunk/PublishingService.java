package hk.org.empf.cas.contribution.chunk;

import hk.org.empf.cas.contribution.chunk.model.DispatchContext;

import java.util.List;
import java.util.UUID;

public interface PublishingService {
    List<UUID> publish(DispatchContext context);
}
