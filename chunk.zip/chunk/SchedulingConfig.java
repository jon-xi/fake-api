package hk.org.empf.cas.contribution.config;

import hk.org.empf.cas.contribution.chunk.config.ChunkingConfig;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Import;
import org.springframework.scheduling.annotation.EnableScheduling;

@ComponentScan
@EnableScheduling
@SuppressWarnings("unused")
@Import({ChunkingConfig.class})
@Configuration(proxyBeanMethods = false)
@ConditionalOnProperty(name = "app.task.enabled", matchIfMissing = true)
public class SchedulingConfig {
}
