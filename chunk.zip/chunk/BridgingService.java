package hk.org.empf.cas.contribution.chunk;

public interface BridgingService {
    void createChunkingTables();

    void removeBridgeTable(String tableName);

    void createBridgeTable(String tableName, String tableDef);
}
